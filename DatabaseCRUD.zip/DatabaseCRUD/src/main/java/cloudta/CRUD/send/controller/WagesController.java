package com.cloudta.notify.send.controller;

import com.cloudta.notify.util.Func;
import com.cloudta.notify.util.R;
import com.alibaba.fastjson.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.cloudta.notify.send.entity.WagesEntity;
import com.cloudta.notify.send.service.WagesService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;
import javax.validation.Valid;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@AllArgsConstructor
@RequestMapping("/test")
@Api(value = "测试", tags = "测试")
@Slf4j
public class WagesController {

    private final WagesService wagesService;

    @GetMapping("/wages/detail")
    @ApiOperation(value = "详情", notes = "传入config")
    public R<WagesEntity> detail(WagesEntity test) {
        WagesEntity detail = wagesService.getById(test.getId());
        return R.data(detail);
    }

    @PostMapping("/wages/create")
    @ApiOperation(value = "新增", notes = "传入config")
    public R create(@Valid @RequestBody WagesEntity user) {
        return R.status(wagesService.save(user));
    }

    @PostMapping("/wages/update")
    @ApiOperation(value = "修改", notes = "传入config")
    public R update(@Valid @RequestBody WagesEntity user) {
//        LambdaQueryWrapper <TestTestEntity> queryWrapper = new LambdaQueryWrapper<>();
//        queryWrapper.eq(TestTestEntity::getId,user.getId());
        QueryWrapper<WagesEntity> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("id", user.getId());
        queryWrapper.eq("code", user.getCode());
        WagesEntity one = wagesService.getOne(queryWrapper);
        if (one != null) {
            return R.status(wagesService.updateById(user));
        } else {
            return R.fail(300, "用户不存在");
        }
    }

    @PostMapping("/wages/remove")
    @ApiOperation(value = "逻辑删除", notes = "传入id")
    public R remove(@RequestBody JSONObject json) {//需要JSON格式
        String id = json.getString("id");
        return R.status(wagesService.deleteLogic(Func.toLongList(id)));
    }

}

