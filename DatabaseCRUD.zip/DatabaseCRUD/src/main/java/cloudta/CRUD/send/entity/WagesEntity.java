package com.cloudta.notify.send.entity;

import com.baomidou.mybatisplus.annotation.TableName;
import com.cloudta.notify.util.BaseEntity;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;




@Data
@TableName("wages")
@EqualsAndHashCode(callSuper = true)
@ApiModel(value = "测试表", description = "测试表")
public class WagesEntity extends BaseEntity{

    private static final long serialVersionUID = 1L;



    @ApiModelProperty(value = "姓名")
    private String name;

    @ApiModelProperty(value = "工号")
    private String code;

    @ApiModelProperty(value = "性别")
    private String gender;

    @ApiModelProperty(value = "发薪日")
    private String issue_time;

    @ApiModelProperty(value = "是否删除")
    private String is_deleted;

    @ApiModelProperty(value = "创建时间")
    private String create_time;
}

