package com.cloudta.notify.send.utils;

import java.util.UUID;

/**
 * UUID工具包
 *
 * @Author wuwuru
 */
public class UUIDUtils {

    /**
     * 生成32位uuid
     *
     * @return
     */
    public static String UUID32() {
        String uuid32 = UUID.randomUUID().toString();
        String UUID = uuid32.replaceAll("-", "");
        return UUID;
    }

    /**
     * 生成32位大写uuid
     *
     * @return
     */
    public static String UUID32UPPER() {
        String uuid32 = UUID.randomUUID().toString();
        String UUID = uuid32.replaceAll("-", "").toUpperCase();
        return UUID;
    }

    /**
     * 生成32位小写uuid
     *
     * @return
     */
    public static String UUID32LOWER() {
        String uuid32 = UUID.randomUUID().toString();
        String UUID = uuid32.replaceAll("-", "").toLowerCase();
        return UUID;
    }
}
