package com.cloudta.notify.send.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloudta.notify.send.entity.WagesEntity;
import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface WagesMapper extends BaseMapper<WagesEntity> {


}
