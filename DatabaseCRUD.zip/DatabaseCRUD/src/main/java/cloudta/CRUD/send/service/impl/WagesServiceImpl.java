package com.cloudta.notify.send.service.impl;

import com.cloudta.notify.send.entity.WagesEntity;
import com.cloudta.notify.send.mapper.WagesMapper;
import com.cloudta.notify.send.service.WagesService;
import com.cloudta.notify.util.BaseServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class WagesServiceImpl extends BaseServiceImpl<WagesMapper, WagesEntity> implements WagesService {

    @Autowired
    private WagesMapper wagesMapper;



}

