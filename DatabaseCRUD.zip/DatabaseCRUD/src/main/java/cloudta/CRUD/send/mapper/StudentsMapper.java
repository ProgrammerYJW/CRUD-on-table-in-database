package com.cloudta.notify.send.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.cloudta.notify.send.entity.StudentsEntity;
import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface StudentsMapper extends BaseMapper<StudentsEntity> {


}
