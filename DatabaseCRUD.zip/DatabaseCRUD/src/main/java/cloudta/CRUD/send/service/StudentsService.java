
package com.cloudta.notify.send.service;


import com.cloudta.notify.send.entity.StudentsEntity;
import com.cloudta.notify.util.BaseService;



public interface StudentsService extends BaseService<StudentsEntity> {

}


