package com.cloudta.notify.send.service.impl;


import com.cloudta.notify.send.entity.StudentsEntity;
import com.cloudta.notify.send.mapper.StudentsMapper;
import com.cloudta.notify.send.service.StudentsService;
import com.cloudta.notify.util.BaseServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class StudentsServiceImpl extends BaseServiceImpl<StudentsMapper, StudentsEntity> implements StudentsService {

    @Autowired
    private StudentsMapper studentsMapper;



}
