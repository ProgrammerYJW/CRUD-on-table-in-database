package com.cloudta.notify.send.service;

import com.cloudta.notify.send.entity.WagesEntity;
import com.cloudta.notify.util.BaseService;



public interface WagesService extends BaseService<WagesEntity> {

}
