package com.cloudta.notify;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class CloudtaNotifyApplication {

    public static void main(String[] args) {
        SpringApplication.run(CloudtaNotifyApplication.class,args);
    }

}
