package com.cloudta.notify.util;


import javax.validation.constraints.NotEmpty;
import java.util.List;

public interface BaseService<T> extends IService<T> {
    boolean deleteLogic(@NotEmpty List<Long> ids);

    boolean changeStatus(@NotEmpty List<Long> id, Integer status);
}
