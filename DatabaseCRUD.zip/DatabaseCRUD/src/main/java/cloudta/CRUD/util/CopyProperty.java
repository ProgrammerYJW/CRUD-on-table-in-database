package com.cloudta.notify.util;

import java.lang.annotation.*;

@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface CopyProperty {
    String value() default "";

    boolean ignore() default false;
}
