package com.cloudta.notify.util;

import java.io.Closeable;
import java.io.Flushable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;

import org.apache.commons.codec.Charsets;
import org.springframework.lang.Nullable;
import org.springframework.util.StreamUtils;

public class IoUtil extends StreamUtils {
    public IoUtil() {
    }

    public static void closeQuietly(@Nullable Closeable closeable) {
        if (closeable != null) {
            if (closeable instanceof Flushable) {
                try {
                    ((Flushable)closeable).flush();
                } catch (IOException var3) {
                }
            }

            try {
                closeable.close();
            } catch (IOException var2) {
            }

        }
    }

    public static String readToString(InputStream input) throws Exception {
        return readToString(input, Charsets.UTF_8);
    }

    public static String readToString(@Nullable InputStream input, Charset charset) throws Exception {
        String var2;
        try {
            var2 = copyToString(input, charset);
        } catch (Exception e) {
            throw e;
        } finally {
            closeQuietly(input);
        }

        return var2;
    }

    public static byte[] readToByteArray(@Nullable InputStream input) throws IOException {
        byte[] var1;
        try {
            var1 = copyToByteArray(input);
        } catch (Exception e) {
            throw e;
        } finally {
            closeQuietly(input);
        }

        return var1;
    }

    public static void write(@Nullable final String data, final OutputStream output, final Charset encoding) throws IOException {
        if (data != null) {
            output.write(data.getBytes(encoding));
        }

    }
}
