
USE `cloudta_notify`;

ALTER TABLE `cloudta_notify_history` ADD `user_secret_key` VARCHAR(64) DEFAULT NULL COMMENT '用户密钥';
