
USE `cloudta_notify`;

/*Table structure for table `cloudta_foundation_temp` */

DROP TABLE IF EXISTS `cloudta_foundation_temp`;

CREATE TABLE `cloudta_foundation_temp` (
  `id` bigint(64) NOT NULL,
  `name` varchar(64) NOT NULL COMMENT '名称',
  `use_range` tinyint(4) NOT NULL COMMENT '使用范围 0:公开  1:系统',
  `service_id` varchar(64) NOT NULL COMMENT '通知服务id',
  `service_name` varchar(64) NOT NULL COMMENT '通知服务名称',
  `type` varchar(64) NOT NULL COMMENT '类型',
  `type_name` varchar(64) NOT NULL COMMENT '类型名称',
  `provider` varchar(64) NOT NULL COMMENT '供应商',
  `provider_name` varchar(64) NOT NULL COMMENT '供应商名称',
  `configuration` text COMMENT '配置',
  `temp_param` text COMMENT 'temp参数',
  `temp_content` text COMMENT 'temp内容',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `is_deleted` tinyint(4) DEFAULT NULL COMMENT '是否已删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Table structure for table `cloudta_notify_history` */

DROP TABLE IF EXISTS `cloudta_notify_history`;

CREATE TABLE `cloudta_notify_history` (
  `id` bigint(64) NOT NULL,
  `recipient` varchar(255) DEFAULT NULL COMMENT '接收对象',
  `recipient_name` varchar(255) DEFAULT NULL COMMENT '接收对象名称',
  `sender` varchar(255) DEFAULT NULL COMMENT '发送对象',
  `sender_name` varchar(255) DEFAULT NULL COMMENT '发送对象名称',
  `template_id` bigint(64) NOT NULL COMMENT '模板id',
  `template_name` varchar(255) NOT NULL COMMENT '模板名称',
  `template` text COMMENT '模板',
  `type` varchar(32) NOT NULL COMMENT '通知类型',
  `type_name` varchar(255) NOT NULL COMMENT '通知类型名称',
  `notify_time` datetime(6) DEFAULT NULL COMMENT '通知时间',
  `notifier_id` varchar(64) NOT NULL COMMENT '通知id',
  `retry_time` int(11) NOT NULL DEFAULT '0' COMMENT '重试次数',
  `provider` varchar(32) NOT NULL COMMENT '服务商',
  `provider_name` varchar(255) NOT NULL COMMENT '服务商名称',
  `error_type` varchar(1024) DEFAULT NULL,
  `content` text COMMENT '内容',
  `context` text,
  `error_stack` text,
  `state` varchar(255) NOT NULL,
  `reason` text COMMENT '错误原因',
  `unit_price` varchar(64) DEFAULT NULL COMMENT '单价',
  `tradelog_id` bigint(64) DEFAULT NULL COMMENT '消费日志id',
  `call_id` varchar(255) DEFAULT NULL COMMENT '通知id',
  `call_time` varchar(255) DEFAULT NULL COMMENT '通话时长',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `is_deleted` tinyint(4) DEFAULT NULL COMMENT '是否已删除',
  `user_id` varchar(128) DEFAULT NULL COMMENT '用户id',
  PRIMARY KEY (`id`),
  KEY `idx_nt_his_notifier_id` (`notifier_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Table structure for table `cloudta_notify_service` */

DROP TABLE IF EXISTS `cloudta_notify_service`;

CREATE TABLE `cloudta_notify_service` (
  `id` bigint(64) NOT NULL,
  `name` varchar(255) NOT NULL COMMENT '名称',
  `type` varchar(64) NOT NULL COMMENT '类型',
  `type_name` varchar(64) NOT NULL COMMENT '类型名称',
  `provider` varchar(64) NOT NULL COMMENT '供应商',
  `provider_name` varchar(64) NOT NULL COMMENT '供应商名称',
  `configuration` text NOT NULL COMMENT '配置',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `is_deleted` tinyint(4) DEFAULT NULL COMMENT '是否已删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Table structure for table `cloudta_notify_template` */

DROP TABLE IF EXISTS `cloudta_notify_template`;

CREATE TABLE `cloudta_notify_template` (
  `id` bigint(64) NOT NULL,
  `name` varchar(64) NOT NULL COMMENT '名称',
  `type` varchar(64) NOT NULL COMMENT '类型',
  `type_name` varchar(64) NOT NULL COMMENT '类型名称',
  `provider` varchar(64) NOT NULL COMMENT '供应商',
  `provider_name` varchar(64) NOT NULL COMMENT '供应商名称',
  `foundation_temp_id` bigint(64) NOT NULL COMMENT '通知基础模板id',
  `foundation_temp_name` varchar(64) NOT NULL COMMENT '通知基础模板名称',
  `configuration` text COMMENT '配置',
  `temp_param` text COMMENT 'temp参数',
  `temp_content` text COMMENT 'temp内容',
  `user_id` bigint(64) NOT NULL COMMENT '用户id',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `is_deleted` tinyint(4) DEFAULT NULL COMMENT '是否已删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Table structure for table `cloudta_notify_user` */

DROP TABLE IF EXISTS `cloudta_notify_user`;

CREATE TABLE `cloudta_notify_user` (
  `id` bigint(64) NOT NULL,
  `nickname` varchar(64) DEFAULT NULL COMMENT '昵称',
  `name` varchar(128) NOT NULL COMMENT '账号',
  `password` varchar(255) NOT NULL COMMENT '密码',
  `type` tinyint(4) DEFAULT NULL COMMENT '0:激活 1:禁用',
  `role` tinyint(4) DEFAULT NULL COMMENT '0:管理员 1:普通用户',
  `account_number` decimal(10,2) DEFAULT NULL COMMENT '账号额度',
  `unitprice` text COMMENT '单价',
  `phone` varchar(64) DEFAULT NULL COMMENT '手机号',
  `mail` varchar(64) DEFAULT NULL COMMENT '邮箱',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `is_deleted` tinyint(4) DEFAULT NULL COMMENT '是否已删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `cloudta_notify_user` */

insert  into `cloudta_notify_user`(`id`,`nickname`,`name`,`password`,`type`,`role`,`account_number`,`unitprice`,`phone`,`mail`,`description`,`create_time`,`is_deleted`) values (1625392397298626561,'管理员','admin','e10adc3949ba59abbe56e057f20f883e',0,0,'100.00','{\"sms\":0.1,\"voice\":0.2}',NULL,NULL,'测试01','2023-02-14 15:12:00',1);

/*Table structure for table `cloudta_system_param` */

DROP TABLE IF EXISTS `cloudta_system_param`;

CREATE TABLE `cloudta_system_param` (
  `id` bigint(64) NOT NULL,
  `name` varchar(255) NOT NULL COMMENT '参数名称',
  `param_key` varchar(64) NOT NULL COMMENT '参数key',
  `param_value` varchar(500) DEFAULT NULL COMMENT '参数值',
  `description` varchar(255) DEFAULT NULL COMMENT '描述',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `is_deleted` tinyint(4) DEFAULT NULL COMMENT '是否已删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

/*Data for the table `cloudta_system_param` */

insert  into `cloudta_system_param`(`id`,`name`,`param_key`,`param_value`,`description`,`create_time`,`is_deleted`) values (1673230924071944194,'单价','unitprice','[{\"key\":\"sms\",\"name\":\"短信\"},{\"key\":\"voice\",\"name\":\"语音\"}]',NULL,'2023-06-26 15:25:14',1),(1673585738962264066,'服务类型','serviceType','[{\"name\":\"短信\",\"value\":\"sms\"},{\"name\":\"电话\",\"value\":\"voice\"},{\"name\":\"微信\",\"value\":\"wechat\"},{\"name\":\"企业微信\",\"value\":\"qywechat\"},{\"name\":\"钉钉\",\"value\":\"dingtalk\"}]','服务类型','2023-06-27 14:55:09',1),(1673591696660717570,'供应商类型','providerType','[{\"type\":\"voice\",\"id\":\"aliyun\",\"name\":\"阿里云\"},{\"type\":\"qywechat\",\"id\":\"qywechat\",\"name\":\"企业微信消息通知\"},{\"type\":\"sms\",\"id\":\"aliyunSms\",\"name\":\"阿里云短信服务\"},{\"type\":\"dingtalk\",\"id\":\"dingtalk\",\"name\":\"钉钉消息通知\"},{\"type\":\"wechat\",\"id\":\"wechatSms\",\"name\":\"微信消息通知\"}]','供应商类型','2023-06-27 15:18:49',1),(1677199883171278850,'支付配置','payConf','{\n    \"name\":\"notify\",\n    \"password\":\"123456\",\n    \"configId\":\"1677214276046344193\",\n    \"ip\":\"192.168.1.41:31225\",\n    \"publicKey\":\"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCFoUQCYatgjAFvI9gIigpmR6uTjGGslv8apSWX7cCOKWFOPkgs0QE8Z4iO2S5EzApxMDNXqmfPC8YsOkoDNPV5bLoybC1y-4zOIVhJIvNNm5xTLk5sufY5GJo-s4v8Qnv-0F0GiXjVG9ocETl4vRhIBpG6nz__ku91NTbeThgx0wIDAQAB\"\n}','支付配置','2023-07-07 14:16:28',1);

/*Table structure for table `cloudta_trade_log` */

DROP TABLE IF EXISTS `cloudta_trade_log`;

CREATE TABLE `cloudta_trade_log` (
  `id` bigint(64) NOT NULL COMMENT '主键',
  `user_id` varchar(64) DEFAULT NULL COMMENT '用户id',
  `user_name` varchar(64) DEFAULT NULL COMMENT '用户名称',
  `trade_type` tinyint(4) DEFAULT NULL COMMENT '交易类型 0:消费 1:退款 2:充值',
  `type` tinyint(4) DEFAULT NULL COMMENT '交易状态 0:退款成功 1:退款失败 2:发起退款 3:拒绝退款',
  `original_amount` varchar(64) DEFAULT NULL COMMENT '原数额',
  `transaction_amount` varchar(64) DEFAULT NULL COMMENT '交易额',
  `balance` varchar(64) DEFAULT NULL COMMENT '余额',
  `log_id` varchar(64) DEFAULT NULL COMMENT '通知日志id',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `refund_time` datetime DEFAULT NULL COMMENT '退款时间',
  `is_deleted` tinyint(4) DEFAULT NULL COMMENT '是否已删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='交易日志表';

/*Table structure for table `cloudta_user_key` */

DROP TABLE IF EXISTS `cloudta_user_key`;

CREATE TABLE `cloudta_user_key` (
  `id` bigint(64) NOT NULL,
  `user_id` varchar(64) NOT NULL COMMENT '用户id',
  `name` varchar(255) NOT NULL COMMENT '密钥名称',
  `secret_key` varchar(96) NOT NULL COMMENT '密钥',
  `create_time` datetime DEFAULT NULL COMMENT '创建时间',
  `is_deleted` tinyint(4) DEFAULT NULL COMMENT '是否已删除',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
