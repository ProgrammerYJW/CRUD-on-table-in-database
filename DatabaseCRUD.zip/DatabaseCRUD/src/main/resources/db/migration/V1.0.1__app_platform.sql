
USE `cloudta_notify`;

delete from cloudta_system_param where id = '1673230924071944194';
delete from cloudta_system_param where id = '1673585738962264066';
delete from cloudta_system_param where id = '1673591696660717570';
delete from cloudta_system_param where id = '1677199883171278850';
delete from cloudta_system_param where id = '1689161773980180481';
insert into `cloudta_system_param` (`id`, `name`, `param_key`, `param_value`, `description`, `create_time`, `is_deleted`) values('1673230924071944194','单价','unitprice','[{\"key\":\"sms\",\"name\":\"短信\"},{\"key\":\"voice\",\"name\":\"语音\"},{\"key\":\"wechat\",\"name\":\"微信\"}]',NULL,'2023-06-26 15:25:14','1');
insert into `cloudta_system_param` (`id`, `name`, `param_key`, `param_value`, `description`, `create_time`, `is_deleted`) values('1673585738962264066','服务类型','serviceType','[{\"name\":\"短信\",\"value\":\"sms\"},{\"name\":\"电话\",\"value\":\"voice\"},{\"name\":\"微信\",\"value\":\"wechat\"},{\"name\":\"企业微信\",\"value\":\"qywechat\"},{\"name\":\"钉钉\",\"value\":\"dingtalk\"}]','服务类型','2023-06-27 14:55:09','1');
insert into `cloudta_system_param` (`id`, `name`, `param_key`, `param_value`, `description`, `create_time`, `is_deleted`) values('1673591696660717570','供应商类型','providerType','[{\"type\":\"voice\",\"id\":\"aliyun\",\"name\":\"阿里云\"},{\"type\":\"qywechat\",\"id\":\"qywechat\",\"name\":\"企业微信消息通知\"},{\"type\":\"sms\",\"id\":\"aliyunSms\",\"name\":\"阿里云短信服务\"},{\"type\":\"dingtalk\",\"id\":\"dingtalk\",\"name\":\"钉钉消息通知\"},{\"type\":\"wechat\",\"id\":\"wechatSms\",\"name\":\"微信消息通知\"}]','供应商类型','2023-06-27 15:18:49','1');
insert into `cloudta_system_param` (`id`, `name`, `param_key`, `param_value`, `description`, `create_time`, `is_deleted`) values('1677199883171278850','支付配置','payConf','{\n    \"name\":\"notify\",\n    \"password\":\"123456\",\n    \"configId\":\"1677214276046344193\",\n    \"ip\":\"192.168.1.41:31225\",\n    \"publicKey\":\"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCFoUQCYatgjAFvI9gIigpmR6uTjGGslv8apSWX7cCOKWFOPkgs0QE8Z4iO2S5EzApxMDNXqmfPC8YsOkoDNPV5bLoybC1y-4zOIVhJIvNNm5xTLk5sufY5GJo-s4v8Qnv-0F0GiXjVG9ocETl4vRhIBpG6nz__ku91NTbeThgx0wIDAQAB\"\n}','支付配置','2023-07-07 14:16:28','1');
insert into `cloudta_system_param` (`id`, `name`, `param_key`, `param_value`, `description`, `create_time`, `is_deleted`) values('1689161773980180481','微信授权页面','wechatUrl','http://notify.cloudta.cn/#/wxauth','微信授权','2023-08-09 14:28:45','1');

delete from cloudta_notify_user where id = '1625392397298626561';
insert into `cloudta_notify_user` (`id`, `nickname`, `name`, `password`, `type`, `role`, `account_number`, `unitprice`, `phone`, `mail`, `description`, `create_time`, `is_deleted`) values('1625392397298626561','管理员','admin','aef7b807848b9ccf62ffc611e7f84eef','0','0','84.21','{\"sms\":0.01,\"voice\":0.01,\"wechat\":0.01}',NULL,NULL,'测试01','2023-02-14 15:12:00','1');
