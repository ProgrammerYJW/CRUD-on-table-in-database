
USE `cloudta_notify`;

ALTER TABLE `cloudta_notify_history` ADD `user_key_name` VARCHAR(64) DEFAULT NULL COMMENT '用户密钥名称';
