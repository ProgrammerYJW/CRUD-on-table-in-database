
USE `cloudta_notify`;
delete from cloudta_system_param where id = '1697433369289764865';
insert into `cloudta_system_param` (`id`, `name`, `param_key`, `param_value`, `description`, `create_time`, `is_deleted`) values('1697433369289764865','云塔微信公众号配置','wxConf','{\"appId\":\"wx1a4a275707a9acdb\",\"appSecret\":\"53d21a74ff176b0adf28690af5e1dcbf\"}',NULL,'2023-09-01 10:17:07','1');
ALTER TABLE `cloudta_notify_user` ADD `app_id` VARCHAR(64) DEFAULT NULL COMMENT '微信公众号appId';
ALTER TABLE `cloudta_notify_user` ADD `app_secret` VARCHAR(128) DEFAULT NULL COMMENT '微信公众号appSecret';
