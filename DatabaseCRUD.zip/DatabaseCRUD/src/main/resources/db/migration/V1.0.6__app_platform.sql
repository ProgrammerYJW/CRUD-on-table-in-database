
USE `cloudta_notify`;


ALTER TABLE `cloudta_trade_log` ADD `pay_type` VARCHAR(10) DEFAULT '0' COMMENT '支付渠道';
delete from cloudta_system_param where id = '1677199883171278850';
INSERT INTO `cloudta_system_param` (`id`, `name`, `param_key`, `param_value`, `description`, `create_time`, `is_deleted`) VALUES('1677199883171278850','支付配置','payConf','{\"name\":\"notify\",\"password\":\"123456\",\"configId\":\"1677214276046344193\",\"shouqianbaConfigId\":\"1677214276046344567\",\"ip\":\"139.159.158.58:10058\",\"publicKey\":\"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCFoUQCYatgjAFvI9gIigpmR6uTjGGslv8apSWX7cCOKWFOPkgs0QE8Z4iO2S5EzApxMDNXqmfPC8YsOkoDNPV5bLoybC1y-4zOIVhJIvNNm5xTLk5sufY5GJo-s4v8Qnv-0F0GiXjVG9ocETl4vRhIBpG6nz__ku91NTbeThgx0wIDAQAB\"}','支付配置','2023-07-07 14:16:28','1');
